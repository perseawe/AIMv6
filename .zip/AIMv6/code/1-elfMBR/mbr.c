#include <type.h>
#include <sd-zynq7000.h>

struct elfhdr {
    uint    magic;  // must equal ELF_MAGIC
    uchar   elf[12];
    ushort  type;
    ushort  machine;
    uint    version;
    uint    entry;
    uint    phoff;
    uint    shoff;
    uint    flags;
    ushort  ehsize;
    ushort  phentsize;
    ushort  phnum;
    ushort  shentsize;
    ushort  shnum;
    ushort  shstrndx;
};

struct elfhdr {
    uint    magic;  // must equal ELF_MAGIC
    uchar   elf[12];
    ushort  type;
    ushort  machine;
    uint    version;
    uint    entry;
    uint    phoff;
    uint    shoff;
    uint    flags;
    ushort  ehsize;
    ushort  phentsize;
    ushort  phnum;
    ushort  shentsize;
    ushort  shnum;
    ushort  shstrndx;
};

void (*uart_spin_puts)(const char *) = (void *)(PRELOAD_VECTOR_BASE + 0xC);

int main()
{
	uart_spin_puts("MBR running...\r\n");
	struct elfhdr *elf;
	struct proghdr *ph, *eph;
	
	sd_init();
	int sd_dma_spin_read_result = sd_dma_spin_read(0x100200, 1, 204800); // read the first block of mmcblk0 to pa 0x100200 (1.5M)

	while (1)
}

